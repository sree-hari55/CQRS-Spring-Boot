package com.cqrs.command.api.event;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProductDeleteEvent {

protected String id;
//protected String name;
//protected BigDecimal price;
//protected int quantity;

}