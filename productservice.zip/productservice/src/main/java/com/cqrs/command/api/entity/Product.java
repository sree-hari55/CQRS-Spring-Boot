package com.cqrs.command.api.entity;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor

@Entity
public class Product {

	
	@Id
	protected String id;
	protected String name;
	protected BigDecimal price;
	protected int quantity;
}
