package com.cqrs.command.api.aggregater;

import java.math.BigDecimal;

import org.axonframework.commandhandling.CommandHandler;
import org.axonframework.eventsourcing.EventSourcingHandler;
import org.axonframework.modelling.command.AggregateIdentifier;
import org.axonframework.modelling.command.AggregateLifecycle;
import org.axonframework.spring.stereotype.Aggregate;
import org.springframework.beans.BeanUtils;

import com.cqrs.command.api.command.CreateProductCommand;
import com.cqrs.command.api.command.DeleteProductCommand;
import com.cqrs.command.api.command.UpdateProductCommand;
import com.cqrs.command.api.event.ProductCreatedEvent;
import com.cqrs.command.api.event.ProductDeleteEvent;
import com.cqrs.command.api.event.ProductUpdateEvent;


@Aggregate
public class ProductAggregator {

	@AggregateIdentifier
	protected String id;
	protected String name;
	protected BigDecimal price;
	protected int quantity;
	
	

	@CommandHandler
	public ProductAggregator(CreateProductCommand createProductCommand) {
		// we can perform validation

		// here we can build new event object or we can use bean utils.
		//ProductCreatedEvent productCreatedEvent=ProductCreatedEvent.builder().build();
		ProductCreatedEvent productCreatedEvent=new ProductCreatedEvent();
		BeanUtils.copyProperties(createProductCommand, productCreatedEvent);
		
		AggregateLifecycle.apply(productCreatedEvent);
	}
	
	@CommandHandler
	public String updateProduct(UpdateProductCommand updateProductCommand) {
        ProductUpdateEvent productUpdateEvent=new ProductUpdateEvent();
        BeanUtils.copyProperties(updateProductCommand, productUpdateEvent);
        AggregateLifecycle.apply(productUpdateEvent);
        return "product updated successfully.";
	}

	@CommandHandler
	public String deleteProduct(DeleteProductCommand deleteProductCommand) {
		ProductDeleteEvent productDeleteEvent=new ProductDeleteEvent();
		BeanUtils.copyProperties(deleteProductCommand, productDeleteEvent);
		AggregateLifecycle.apply(productDeleteEvent);
		return "Product deleted sucessfully";
	}
	// we are updating the state of an object based on command

	@EventSourcingHandler
	public void on(ProductCreatedEvent productCreatedEvent) {
		this.id=productCreatedEvent.getId();
		this.name=productCreatedEvent.getName();
		this.price=productCreatedEvent.getPrice();
		this.quantity=productCreatedEvent.getQuantity();
	}
}
