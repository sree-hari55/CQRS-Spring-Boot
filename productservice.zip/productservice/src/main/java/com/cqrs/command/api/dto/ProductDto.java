package com.cqrs.command.api.dto;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductDto implements Serializable{

	private static final long serialVersionUID = 1L;
	
	protected String id;
	protected String name;
	protected BigDecimal price;
	protected int quantity;

}
