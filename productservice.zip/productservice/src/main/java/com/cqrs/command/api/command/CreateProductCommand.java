package com.cqrs.command.api.command;

import java.math.BigDecimal;

import org.axonframework.modelling.command.TargetAggregateIdentifier;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor@NoArgsConstructor
public class CreateProductCommand {
	
	@TargetAggregateIdentifier
	protected String id;
	protected String name;
	protected BigDecimal price;
	protected int quantity;

}
