package com.cqrs.query.api.projection;

import java.util.List;
import java.util.stream.Collectors;

import org.axonframework.queryhandling.QueryHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cqrs.command.api.dto.ProductDto;
import com.cqrs.command.api.entity.Product;
import com.cqrs.command.api.repository.ProductRepository;
import com.cqrs.query.api.query.GetAllProductsQuery;
import com.cqrs.query.api.query.GetProductByIdQuery;

@Component
public class ProductProjection {

	@Autowired
	private ProductRepository productRepository;


	@QueryHandler
	public List<ProductDto> getProductsHandler(GetAllProductsQuery getAllProductsQuery){
		List<Product> productList=productRepository.findAll();
		List<ProductDto> productDto=productList.stream().map(p -> ProductDto
				.builder()
				.id(p.getId())
				.name(p.getName())
				.price(p.getPrice())
				.quantity(p.getQuantity())
				.build()).collect(Collectors.toList());
		return productDto;
	}
	
	@QueryHandler
	public ProductDto getProductByIdHandler(GetProductByIdQuery getProductByIdQuery){
		Product product=productRepository.findById(getProductByIdQuery.getId()).get();
		ProductDto productDto=ProductDto
				.builder()
				.id(product.getId())
				.name(product.getName())
				.price(product.getPrice())
				.quantity(product.getQuantity())
				.build();
		return productDto;
	}
}
