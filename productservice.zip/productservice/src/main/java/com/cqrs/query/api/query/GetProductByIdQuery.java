package com.cqrs.query.api.query;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GetProductByIdQuery {

	protected String id;
}
