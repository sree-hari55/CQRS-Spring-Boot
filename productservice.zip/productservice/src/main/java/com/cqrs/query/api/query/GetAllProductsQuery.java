package com.cqrs.query.api.query;


public class GetAllProductsQuery {

}
