package com.cqrs.query.api.controller;

import java.util.List;

import org.axonframework.messaging.responsetypes.ResponseTypes;
import org.axonframework.queryhandling.QueryGateway;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cqrs.command.api.dto.ProductDto;
import com.cqrs.query.api.query.GetAllProductsQuery;
import com.cqrs.query.api.query.GetProductByIdQuery;

@RestController
@RequestMapping("/product/v1/query")
public class ProductQueryController {

	@Autowired
	private QueryGateway queryGateway;

	@GetMapping
	public ResponseEntity<List<ProductDto>> getAllProducts(){
		GetAllProductsQuery getAllProductsQuery=new GetAllProductsQuery();
		List<ProductDto> productDtoList=queryGateway
				.query(getAllProductsQuery, ResponseTypes.multipleInstancesOf(ProductDto.class))
				.join();

		return new ResponseEntity<List<ProductDto>>(productDtoList,HttpStatus.OK);	
	}
	
	@GetMapping(path="/{id}")
	public ResponseEntity<ProductDto> getProductById(@PathVariable String id){
		GetProductByIdQuery getProductByIdQuery=GetProductByIdQuery.builder().id(id).build();
		ProductDto productDto=queryGateway
				.query(getProductByIdQuery, ResponseTypes.instanceOf(ProductDto.class))
				.join();

		return new ResponseEntity<ProductDto>(productDto,HttpStatus.OK);	
	}

}
